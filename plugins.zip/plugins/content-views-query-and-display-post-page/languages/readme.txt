********************************************************

  Content Views I18n
  ============================

  Do not put custom translations here.
  They will be deleted on Content Views updates.

  Keep custom Content Views translations in one of below directories:
	- wp-content/languages/content-views/
	- wp-content/languages/plugins/content-views-query-and-display-post-page/

  You want to translate, help, or improve a translation, please contact us support@contentviewspro.com

********************************************************
